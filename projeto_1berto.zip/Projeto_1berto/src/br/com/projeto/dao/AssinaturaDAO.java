package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.projeto.beans.Assinatura;
import br.com.projeto.beans.Usuario;
import br.com.projeto.conexao.Conexao;

public class AssinaturaDAO {

	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;

	public AssinaturaDAO() throws Exception {
		con = Conexao.queroConectar();
	}

	public int addAssinatura(Assinatura a) throws Exception {
		stmt = con.prepareStatement(
				"INSERT INTO RW_T_ASSINATURA(CD_ASSINATURA, TP_ASSINATURA, VL_ASSINATURA, DT_ASSINATURA, ID_USUARIO) VALUES (?,?,?,?,?)");
		stmt.setInt(1, a.getCodigo());
		stmt.setString(2, a.getTipo());
		stmt.setDouble(3, a.getValor());
		stmt.setString(4, a.getData());
		stmt.setInt(5, a.getUsuario().getCodigo());
		return stmt.executeUpdate();
	}
	public boolean verificarUsuario(int codUser)  throws Exception {
		stmt = con.prepareStatement("select * from RW_T_ASSINATURA where ID_USUARIO=?");
		stmt.setInt(1, codUser);
		rs = stmt.executeQuery();
		return rs.next();
	}
	public Assinatura getAssinatura(int codAss) throws Exception {
		stmt = con.prepareStatement("select * from RW_T_ASSINATURA where CD_ASSINATURA=?");
		stmt.setInt(1, codAss);
		rs = stmt.executeQuery();
		UsuarioDAO dao = new UsuarioDAO();
		if (rs.next()) {
			Assinatura assinatura = new Assinatura(rs.getInt("CD_ASSINATURA"), rs.getString("TP_ASSINATURA"), rs.getDouble("VL_ASSINATURA"), rs.getString("DT_ASSINATURA"), dao.getUser(rs.getInt("ID_USUARIO")));
			dao.encerrar();
			return assinatura;
		} else {
			return new Assinatura();
		}
	}

	public int deleteUser(int codAss) throws Exception {
		stmt = con.prepareStatement("delete from RW_T_ASSINATURA where CD_ASSINATURA=?");
		stmt.setInt(1, codAss);
		return stmt.executeUpdate();
	}
	
	public void encerrar() throws Exception {
		con.close();
	}

}
