package br.com.projeto.bo;

import br.com.projeto.beans.Usuario;
import br.com.projeto.dao.AssinaturaDAO;
import br.com.projeto.dao.UsuarioDAO;

public class UsuarioBO {

	public int novoUsuario(Usuario objUsuario) throws Exception { // mesmo tipo de retorno do dao addUser
		if (objUsuario.getNome().length() > 50) {
			throw new RuntimeException("Excdeu caracteres");
		}
		if (objUsuario.getNome().length() <= 3) {
			throw new RuntimeException("Poucos caracteres");
		}
		if (objUsuario.getNome().length() < 3 || objUsuario.getSenha().length() > 15) {
			throw new RuntimeException("Senha deve estar entre");
		}
		objUsuario.setNome(objUsuario.getNome().toUpperCase());
		UsuarioDAO dao = new UsuarioDAO();
		if (dao.getUser(objUsuario.getCodigo()).getCodigo() == 0) {
			// n�o tem chave primaira que � igual ao novo usu�rio
			dao.addUser(objUsuario);
			dao.encerrar();
			return 1;
		} else {
			// o c�digo j� existe
			dao.encerrar();
			return 0;
		}

	}
	
	public String excluirUsuario(int cod) throws Exception {
		AssinaturaDAO daoA = new AssinaturaDAO();
		UsuarioDAO daoU = new UsuarioDAO();
		if(cod <= 0) return "C�digo inv�lido";
		
		if(daoU.getUser(cod).getCodigo() == 0) {
			daoU.encerrar();
			return "Usu�rio n�o existe";
		}
		
		if(daoA.verificarUsuario(cod)) {
			return "Usuario em uso";
		}
			daoU.killUser(cod);
			
			daoA.encerrar();
			daoU.encerrar();
			
			return "Usu�rio exclu�do";
		
		
	}
	
	
	
	

}
