package br.com.projeto.principal;



import br.com.projeto.beans.Usuario;
import br.com.projeto.bo.UsuarioBO;

public class TesteNovoUsuario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			UsuarioBO bo = new UsuarioBO();
			
			
			if(bo.novoUsuario(new Usuario(5,"BRENOSAPIDAPOSDOPASDIPOAISPDOAASDASDASDASDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD","ASKLDJAKSLJDAKSLJDKALSJDKLAJSDLKAJSLKASJDLAKSDJALSKDJKALSDJKALSJDKALSD")) == 1) {
				System.out.println("Cadasro com sucesso");
			} else {
				System.out.println("N�o cadastrado");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
