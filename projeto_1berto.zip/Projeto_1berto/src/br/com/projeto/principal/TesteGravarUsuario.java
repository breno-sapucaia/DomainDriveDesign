package br.com.projeto.principal;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Usuario;
import br.com.projeto.dao.UsuarioDAO;

public class TesteGravarUsuario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		UsuarioDAO dao = null;

		try {
			dao = new UsuarioDAO();
//			Usuario usu = new Usuario();
//			usu.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Digite o c�digo: ")));
//			usu.setNome(JOptionPane.showInputDialog("Digite o nome: "));
//			usu.setSenha(JOptionPane.showInputDialog("Digite o senha: "));
//			if(dao.addUser(usu)==0) {
//				System.out.println("N�o cadastrado!");
//			}else {
//				System.out.println("Cadastrado com sucesso!");
//			}
			
			if(dao.addUser(new Usuario(Integer.parseInt(JOptionPane.showInputDialog("Digite o c�digo: ")),
					JOptionPane.showInputDialog("Digite o nome: "),
					JOptionPane.showInputDialog("Digite o senha: ")))==0){
				System.out.println("N�o cadastrado!");
			}else {
				System.out.println("Cadastrado com sucesso!");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dao.encerrar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
