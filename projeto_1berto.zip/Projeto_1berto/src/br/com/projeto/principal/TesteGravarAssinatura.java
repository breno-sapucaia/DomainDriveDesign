package br.com.projeto.principal;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Assinatura;
import br.com.projeto.beans.Usuario;
import br.com.projeto.dao.AssinaturaDAO;

public class TesteGravarAssinatura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AssinaturaDAO dao = null;
		
		try {
			dao = new AssinaturaDAO();
			if(dao.addAssinatura(new Assinatura(Integer.parseInt(JOptionPane.showInputDialog("Digite seu c�digo: ")),
				JOptionPane.showInputDialog("Digite o tipo: "),
					Double.parseDouble(JOptionPane.showInputDialog("Digite o valor: ")),
					JOptionPane.showInputDialog("Digite a data: "),
					new Usuario(Integer.parseInt(JOptionPane.showInputDialog("Digite seu c�digo de usu�rio: ")), JOptionPane.showInputDialog("Digite o nome: "), JOptionPane.showInputDialog("Digite a senha: "))))==0) {
				System.out.println("N�o Gravou!");
				
			}else {
				System.out.println("Gravado com sucesso!");
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dao.encerrar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}

}
