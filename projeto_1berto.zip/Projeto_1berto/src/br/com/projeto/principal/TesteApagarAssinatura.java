package br.com.projeto.principal;

import javax.swing.JOptionPane;

import br.com.projeto.dao.AssinaturaDAO;

public class TesteApagarAssinatura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AssinaturaDAO dao = null;
		try {
			dao = new AssinaturaDAO();
			if (dao.deleteUser(Integer.parseInt(JOptionPane.showInputDialog("Digite o c�digo: "))) == 0) {
				System.out.println("Usu�rio n�o encontrado.");
			} else {
				System.out.println("Killed...");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dao.encerrar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
