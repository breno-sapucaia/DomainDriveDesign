package br.com.projeto.principal;

import br.com.projeto.beans.Assinatura;
import br.com.projeto.dao.AssinaturaDAO;

public class TesteConsultarAssinatura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AssinaturaDAO dao = null;
		try {
			dao = new AssinaturaDAO();
			Assinatura u = dao.getAssinatura(1);
			System.out.println(u.getTipo());
			System.out.println(u.getValor());
			System.out.println(u.getData());
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dao.encerrar();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}

}
